import React from "react";

const ChildrenCom = (props) => {
  return <div>{props.children}</div>;
};

export default ChildrenCom;
